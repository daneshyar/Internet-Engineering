     let oper=prompt('please Enter + or - or * or / or ^');
     let a=prompt('please Enter first number');
     let b=prompt('please Enter second number');
     if(oper=='+'){
        alert(+a + +b);
     } else if(oper=='-'){
        alert(a-b);
     } else if(oper=='*'){
        alert(a*b);
     } else if(oper=='/'){
        alert(a/b);
     } else if(oper=='^'){
        alert(a**b);
    } else{
     alert('Error!please enter oper again');
    }
